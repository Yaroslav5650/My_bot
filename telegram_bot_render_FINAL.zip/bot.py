import telebot

BOT_TOKEN = '7869246247:AAE7Z0ixfF_nhil6MOFJlMxUiOwmf-B1jg4'
OWNER_ID = 1254290520   # замени на свой ID, если нужно

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(content_types=['text', 'photo', 'video', 'document', 'audio', 'voice', 'sticker', 'animation'])
def forward_all(message):
    if message.chat.id != OWNER_ID:
        bot.forward_message(OWNER_ID, message.chat.id, message.message_id)
    else:
        bot.send_message(OWNER_ID, "✅")

bot.polling()